import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { apiRequest } from "./api.js";
import {
  Routes, Route, Link, NavLink, useNavigate, useParams, useLocation
} from "react-router-dom";
import {
  ShoppingCart, Search, Heart, Menu, X, Star, Plus, Minus, Trash2,
  ArrowRight, PackageCheck, ShieldCheck, Truck, Sparkles, LogOut, UserRound
} from "lucide-react";

const products = [
  { id: 1, name: "Rainbow Building Blocks", category: "Learning", price: 599, oldPrice: 799, rating: 4.8, reviews: 124, emoji: "🧱", color: "#e6f4ff", description: "A colourful set of sturdy building blocks that encourages creativity, problem-solving and hours of imaginative play.", age: "3+ years", tag: "Bestseller" },
  { id: 2, name: "Cuddle Bear Plushie", category: "Soft Toys", price: 449, oldPrice: 599, rating: 4.9, reviews: 98, emoji: "🧸", color: "#fff0e6", description: "A super-soft teddy bear friend, perfect for hugs, bedtime stories and everyday adventures.", age: "1+ years", tag: "Popular" },
  { id: 3, name: "Mini Race Car Set", category: "Vehicles", price: 799, oldPrice: 999, rating: 4.7, reviews: 76, emoji: "🏎️", color: "#ffe8ec", description: "A fast and fun collection of mini racing cars for exciting races and imaginative track adventures.", age: "4+ years", tag: "New" },
  { id: 4, name: "Little Chef Play Kitchen", category: "Pretend Play", price: 1499, oldPrice: 1799, rating: 4.8, reviews: 53, emoji: "🍳", color: "#fff5d9", description: "A pretend kitchen play set that lets little chefs create make-believe meals and learn through role play.", age: "3+ years", tag: "Featured" },
  { id: 5, name: "Dino Explorer Figure", category: "Action Toys", price: 349, oldPrice: 449, rating: 4.6, reviews: 61, emoji: "🦖", color: "#eaf7e9", description: "Meet a friendly dinosaur figure for prehistoric adventures, storytelling and imaginative play.", age: "3+ years", tag: "" },
  { id: 6, name: "Starry Art Kit", category: "Arts & Crafts", price: 699, oldPrice: 899, rating: 4.9, reviews: 87, emoji: "🎨", color: "#f2eaff", description: "A creative art kit with colourful supplies to inspire drawing, colouring and handmade masterpieces.", age: "5+ years", tag: "Creative pick" },
  { id: 7, name: "Wooden Puzzle Garden", category: "Learning", price: 529, oldPrice: 699, rating: 4.7, reviews: 42, emoji: "🧩", color: "#e8f6f3", description: "A charming wooden puzzle that supports shape recognition, patience and fine motor skills.", age: "2+ years", tag: "" },
  { id: 8, name: "Rocket Adventure Set", category: "Vehicles", price: 899, oldPrice: 1099, rating: 4.8, reviews: 39, emoji: "🚀", color: "#e9efff", description: "Blast off into imaginative space missions with this fun rocket adventure play set.", age: "4+ years", tag: "" },
  { id: 9, name: "Dancing Unicorn Plush", category: "Soft Toys", price: 649, oldPrice: 799, rating: 4.9, reviews: 34, emoji: "🦄", color: "#fceafa", description: "A magical, cuddly unicorn companion for storytelling, hugs and imaginative adventures.", age: "2+ years", tag: "New" },
  { id: 10, name: "Jungle Animal Set", category: "Learning", price: 399, oldPrice: 499, rating: 4.7, reviews: 28, emoji: "🦁", color: "#edf6df", description: "Discover wildlife with a colourful collection of animal figures for creative play.", age: "3+ years", tag: "" },
  { id: 11, name: "Junior Doctor Kit", category: "Pretend Play", price: 749, oldPrice: 899, rating: 4.8, reviews: 47, emoji: "🩺", color: "#e5f5f5", description: "A pretend medical kit that encourages caring role-play and confidence.", age: "3+ years", tag: "Popular" },
  { id: 12, name: "Dinosaur Puzzle", category: "Learning", price: 299, oldPrice: 399, rating: 4.6, reviews: 31, emoji: "🦕", color: "#eaf7e9", description: "A fun dinosaur-themed puzzle to build patience, focus and problem-solving skills.", age: "4+ years", tag: "" },
  { id: 13, name: "Kids Art & Colour Kit", category: "Arts & Crafts", price: 549, oldPrice: 699, rating: 4.8, reviews: 52, emoji: "🖍️", color: "#f2eaff", description: "A colourful creative kit for drawing, colouring and making little masterpieces.", age: "5+ years", tag: "Creative pick" },
  { id: 14, name: "Remote Control Monster Truck", category: "Vehicles", price: 1299, oldPrice: 1599, rating: 4.7, reviews: 43, emoji: "🚙", color: "#fff0e6", description: "Take exciting off-road adventures to the living room with this monster truck.", age: "6+ years", tag: "" },
  { id: 15, name: "Magnetic Shape Tiles", category: "Learning", price: 999, oldPrice: 1199, rating: 4.9, reviews: 65, emoji: "🔷", color: "#e6f4ff", description: "Build colourful 2D and 3D creations while exploring shapes and spatial thinking.", age: "3+ years", tag: "Bestseller" },
  { id: 16, name: "Tea Party Play Set", category: "Pretend Play", price: 699, oldPrice: 849, rating: 4.6, reviews: 25, emoji: "🫖", color: "#fff5d9", description: "Host a make-believe tea party and enjoy hours of friendly role-play.", age: "3+ years", tag: "" },
  { id: 17, name: "Wooden Train Track", category: "Vehicles", price: 1099, oldPrice: 1399, rating: 4.8, reviews: 38, emoji: "🚂", color: "#e9efff", description: "Create your own railway routes with a classic wooden train play set.", age: "3+ years", tag: "" },
  { id: 18, name: "Dinosaur Hand Puppet", category: "Soft Toys", price: 379, oldPrice: 499, rating: 4.7, reviews: 29, emoji: "🦖", color: "#eaf7e9", description: "Bring stories to life with a friendly dinosaur puppet and playful characters.", age: "2+ years", tag: "" },
  { id: 19, name: "Rainbow Bead Craft Set", category: "Arts & Crafts", price: 459, oldPrice: 599, rating: 4.8, reviews: 36, emoji: "📿", color: "#fceafa", description: "Make colourful patterns and simple craft creations with this activity set.", age: "5+ years", tag: "" },
  { id: 20, name: "Space Explorer Play Set", category: "Action Toys", price: 899, oldPrice: 1099, rating: 4.9, reviews: 41, emoji: "👩‍🚀", color: "#e9efff", description: "Create exciting space missions with an astronaut and accessories.", age: "5+ years", tag: "Adventure pick" }
];

const StoreContext = createContext(null);
const useStore = () => useContext(StoreContext);
const money = (n) => `₹${n.toLocaleString("en-IN")}`;

function StoreProvider({ children }) {
  const [cart, setCart] = useState(() => JSON.parse(localStorage.getItem("toyland-cart") || "[]"));
  const [user, setUserState] = useState(() => JSON.parse(localStorage.getItem("toyland-user") || "null"));
  const setUser = (nextUser) => {
    if (nextUser?.token) localStorage.setItem("toyland-token", nextUser.token);
    if (!nextUser) localStorage.removeItem("toyland-token");
    setUserState(nextUser);
  };
  const [wishlist, setWishlist] = useState([]);
  const [catalog, setCatalog] = useState(products);
  useEffect(() => { apiRequest("/api/products").then(data => { if (Array.isArray(data.products) && data.products.length) setCatalog(data.products.map(p => ({ ...p, id: p.productId }))); }).catch(() => {}); }, []);
  useEffect(() => localStorage.setItem("toyland-cart", JSON.stringify(cart)), [cart]);
  useEffect(() => user ? localStorage.setItem("toyland-user", JSON.stringify(user)) : localStorage.removeItem("toyland-user"), [user]);
  const addToCart = (id) => setCart(old => {
    const found = old.find(item => item.id === id);
    return found ? old.map(item => item.id === id ? { ...item, qty: item.qty + 1 } : item) : [...old, { id, qty: 1 }];
  });
  const updateQty = (id, qty) => setCart(old => qty < 1 ? old.filter(x => x.id !== id) : old.map(x => x.id === id ? { ...x, qty } : x));
  const removeFromCart = (id) => setCart(old => old.filter(x => x.id !== id));
  const count = cart.reduce((sum, x) => sum + x.qty, 0);
  const subtotal = cart.reduce((sum, x) => sum + (catalog.find(p => p.id === x.id)?.price || 0) * x.qty, 0);
  const value = { cart, setCart, user, setUser, wishlist, setWishlist, addToCart, updateQty, removeFromCart, count, subtotal, products: catalog };
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

function Header() {
  const { count, user, setUser } = useStore();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useEffect(() => setOpen(false), [location.pathname]);
  return <header className="site-header">
    <div className="header-inner">
      <Link to="/home" className="brand"><span className="brand-icon">🧸</span><span>Toy<span>Land</span><small>PLAY MORE, SMILE MORE</small></span></Link>
      <button className="mobile-menu" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
      <nav className={open ? "nav-links open" : "nav-links"}>
        <NavLink to="/home">Home</NavLink>
        <NavLink to="/shop">Shop Toys</NavLink>
        <a href="/shop#categories">Categories</a>
      </nav>
      <div className="header-actions">
        <Link className="icon-button account-button" to={user ? "/home" : "/login"} title={user ? user.username : "Login"}><UserRound size={19}/><span>{user ? user.username : "Account"}</span></Link>
        <Link className="icon-button cart-button" to="/cart" aria-label="Shopping cart"><ShoppingCart size={20}/><span>Cart</span><b>{count}</b></Link>
        {user && <button className="logout-button" onClick={() => setUser(null)} title="Sign out"><LogOut size={17}/></button>}
      </div>
    </div>
  </header>;
}

function Footer() {
  return <footer className="footer">
    <div className="footer-inner footer-expanded">
      <div><Link to="/home" className="brand footer-brand"><span className="brand-icon">🧸</span><span>Toy<span>Land</span><small>PLAY MORE, SMILE MORE</small></span></Link><p>Little joys, big adventures. Find a new favourite today!</p></div>
      <div className="footer-column"><b>Explore</b><Link to="/shop">Shop toys</Link><Link to="/about">About us</Link><Link to="/faq">FAQs</Link><Link to="/enquiry">Quick enquiry</Link></div>
      <div className="footer-column"><b>Help & support</b><Link to="/contact">Contact us</Link><Link to="/terms">Terms & conditions</Link><Link to="/privacy">Privacy policy</Link><Link to="/cart">Your cart</Link></div>
    </div>
    <div className="copyright">© 2026 ToyLand. Made for happy playtime.</div>
  </footer>;
}

function Layout({ children }) {
  return <><Header/><main>{children}</main><Footer/></>;
}

function ProductCard({ product }) {
  const { addToCart, wishlist, setWishlist } = useStore();
  const liked = wishlist.includes(product.id);
  return <article className="product-card">
    <div className="product-art" style={{ background: product.color }}>
      {product.tag && <span className="product-tag">{product.tag}</span>}
      <button className={`wish-button ${liked ? "liked" : ""}`} onClick={() => setWishlist(old => liked ? old.filter(x => x !== product.id) : [...old, product.id])} aria-label="Add to wishlist"><Heart size={18} fill={liked ? "currentColor" : "none"}/></button>
      <Link to={`/product/${product.id}`} className="product-emoji">{product.emoji}</Link>
    </div>
    <div className="product-info">
      <span className="product-category">{product.category}</span>
      <Link to={`/product/${product.id}`} className="product-name">{product.name}</Link>
      <div className="rating"><Star size={14} fill="currentColor"/><b>{product.rating}</b><span>({product.reviews})</span></div>
      <div className="product-bottom"><div><strong>{money(product.price)}</strong><del>{money(product.oldPrice)}</del></div><button className="add-button" onClick={() => addToCart(product.id)} aria-label={`Add ${product.name} to cart`}><Plus size={18}/></button></div>
    </div>
  </article>;
}

function Home() {
  const { products } = useStore();
  const categories = [{ name: "Soft Toys", emoji: "🧸", color: "#fff0e6" }, { name: "Learning", emoji: "🧩", color: "#e6f4ff" }, { name: "Vehicles", emoji: "🚗", color: "#ffe8ec" }, { name: "Arts & Crafts", emoji: "🎨", color: "#f2eaff" }];
  return <Layout>
    <section className="hero">
      <div className="hero-copy"><span className="eyebrow"><Sparkles size={15}/> BIG FUN FOR LITTLE ONES</span><h1>Let the fun<br/> <em>begin!</em></h1><p>Discover toys that spark imagination, bring smiles and make every day an adventure.</p><div className="hero-buttons"><Link to="/shop" className="btn btn-primary">Explore toys <ArrowRight size={18}/></Link><a href="#categories" className="btn btn-light">Browse categories</a></div><div className="hero-note"><span>⭐ 4.9/5</span> Loved by happy little customers</div></div>
      <div className="hero-visual"><div className="hero-sun"></div><div className="hero-cloud cloud-one">☁️</div><div className="hero-cloud cloud-two">☁️</div><div className="hero-toy hero-bear">🧸</div><div className="hero-toy hero-rocket">🚀</div><div className="hero-toy hero-blocks">🧱</div><div className="hero-sticker">PLAY<br/>ALL DAY!</div></div>
    </section>
    <section className="benefits"><div><Truck/><span><b>Free delivery</b><small>On orders over ₹999</small></span></div><div><ShieldCheck/><span><b>Safe & trusted</b><small>Made for happy play</small></span></div><div><PackageCheck/><span><b>Easy returns</b><small>7-day return window</small></span></div></section>
    <section className="section-wrap" id="categories"><div className="section-heading"><div><span className="eyebrow">FIND YOUR FAVOURITE</span><h2>Shop by category</h2></div><Link to="/shop" className="text-link">View all toys <ArrowRight size={16}/></Link></div><div className="category-grid">{categories.map(c => <Link to={`/shop?category=${encodeURIComponent(c.name)}`} className="category-card" key={c.name} style={{background:c.color}}><span>{c.emoji}</span><b>{c.name}</b><small>Explore collection →</small></Link>)}</div></section>
    <section className="section-wrap featured-section"><div className="section-heading"><div><span className="eyebrow">HANDPICKED FOR YOU</span><h2>Little favourites</h2><p>Playtime picks that are sure to delight.</p></div><Link to="/shop" className="text-link">Shop all <ArrowRight size={16}/></Link></div><div className="product-grid">{products.slice(0,4).map(p => <ProductCard key={p.id} product={p}/>)}</div></section>
    <section className="newsletter"><div><span className="eyebrow">A LITTLE EXTRA JOY</span><h2>Make room for more fun!</h2><p>Explore playful picks for every curious mind.</p></div><Link to="/shop" className="btn btn-primary">Shop the collection <ArrowRight size={18}/></Link></section>
  </Layout>;
}

function Shop() {
  const { products } = useStore();
  const params = new URLSearchParams(window.location.search);
  const [category, setCategory] = useState(params.get("category") || "All toys");
  const [search, setSearch] = useState("");
  const categories = ["All toys", ...new Set(products.map(p => p.category))];
  const filtered = products.filter(p => (category === "All toys" || p.category === category) && p.name.toLowerCase().includes(search.toLowerCase()));
  return <Layout><section className="page-banner"><span className="eyebrow">THE TOY BOX IS OPEN</span><h1>Find your next favourite</h1><p>From cuddly companions to creative adventures.</p></section><section className="section-wrap shop-section"><div className="shop-toolbar"><div className="filter-pills">{categories.map(c => <button key={c} className={category === c ? "filter-pill active" : "filter-pill"} onClick={() => setCategory(c)}>{c}</button>)}</div><label className="search-box"><Search size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search toys..."/></label></div>{filtered.length ? <div className="product-grid">{filtered.map(p => <ProductCard key={p.id} product={p}/>)}</div> : <div className="empty-state"><span>🔎</span><h3>No toys found</h3><p>Try another search or category.</p><button className="btn btn-primary" onClick={() => {setSearch("");setCategory("All toys");}}>Clear filters</button></div>}</section></Layout>;
}

function ProductDetail() {
  const { id } = useParams();
  const { products, addToCart } = useStore();
  const product = products.find(p => p.id === Number(id));
  const navigate = useNavigate();
  if (!product) return <Layout><div className="empty-state"><h2>Toy not found</h2><Link to="/shop" className="btn btn-primary">Back to shop</Link></div></Layout>;
  return <Layout><section className="detail-wrap"><div className="detail-art" style={{background:product.color}}>{product.emoji}</div><div className="detail-copy"><span className="eyebrow">{product.category}</span><h1>{product.name}</h1><div className="rating detail-rating"><Star size={16} fill="currentColor"/><b>{product.rating}</b><span>{product.reviews} happy reviews</span></div><div className="detail-price">{money(product.price)} <del>{money(product.oldPrice)}</del></div><p>{product.description}</p><div className="detail-facts"><span>🎂 Recommended age: <b>{product.age}</b></span><span>📦 In stock and ready for fun</span></div><button className="btn btn-primary detail-add" onClick={() => {addToCart(product.id);navigate("/cart");}}>Add to cart <ShoppingCart size={18}/></button><Link to="/shop" className="back-link">← Continue shopping</Link></div></section></Layout>;
}

function Cart() {
  const { cart, updateQty, removeFromCart, subtotal, products } = useStore();
  const navigate = useNavigate();
  const delivery = subtotal >= 999 || subtotal === 0 ? 0 : 79;
  return <Layout><section className="page-banner compact-banner"><span className="eyebrow">YOUR PLAYTIME PICKS</span><h1>Shopping cart</h1></section><section className="section-wrap cart-layout">{cart.length ? <><div className="cart-items">{cart.map(item => {const p = products.find(x => x.id === item.id); if (!p) return null; return <div className="cart-row" key={item.id}><div className="cart-thumb" style={{background:p.color}}>{p.emoji}</div><div className="cart-product"><b>{p.name}</b><small>{p.category}</small><strong>{money(p.price)}</strong></div><div className="qty-control"><button onClick={() => updateQty(p.id,item.qty-1)} aria-label="Decrease quantity"><Minus size={14}/></button><span>{item.qty}</span><button onClick={() => updateQty(p.id,item.qty+1)} aria-label="Increase quantity"><Plus size={14}/></button></div><b className="line-total">{money(p.price*item.qty)}</b><button className="remove-button" onClick={() => removeFromCart(p.id)} aria-label="Remove item"><Trash2 size={17}/></button></div>})}</div><aside className="summary-card"><h3>Order summary</h3><div><span>Subtotal</span><b>{money(subtotal)}</b></div><div><span>Delivery</span><b>{delivery === 0 ? "FREE" : money(delivery)}</b></div><p className="delivery-hint">{subtotal >= 999 ? "You unlocked free delivery!" : `Add ${money(Math.max(0,999-subtotal))} more for free delivery.`}</p><div className="summary-total"><span>Total</span><strong>{money(subtotal+delivery)}</strong></div><button className="btn btn-primary checkout-button" onClick={() => navigate("/checkout")}>Proceed to checkout <ArrowRight size={18}/></button><Link to="/shop" className="continue-link">Continue shopping</Link></aside></> : <div className="empty-state cart-empty"><span>🛒</span><h2>Your cart is waiting for fun!</h2><p>You haven't added any toys yet.</p><Link to="/shop" className="btn btn-primary">Explore toys</Link></div>}</section></Layout>;
}

function Checkout() {
  const { cart, subtotal, products } = useStore();
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "", city: "", pincode: "" });
  const navigate = useNavigate();
  const delivery = subtotal >= 999 ? 0 : 79;
  const change = e => setForm({...form,[e.target.name]:e.target.value});
  const [error,setError] = useState(""); const [busy,setBusy] = useState(false);
  const submit = async e => { e.preventDefault(); if (!cart.length) return; setError(""); setBusy(true); try { const result = await apiRequest("/api/orders", { method: "POST", body: JSON.stringify({ ...form, items: cart.map(item => { const p = products.find(x => x.id === item.id); return { productId: item.id, name: p.name, quantity: item.qty, price: p.price }; }) }) }); const order = { id: result.order.orderNumber, ...form, total: result.order.total }; sessionStorage.setItem("toyland-order",JSON.stringify(order)); navigate("/order-success"); } catch (err) { setError(err.message); } finally { setBusy(false); } };
  if (!cart.length) return <Layout><div className="empty-state"><h2>Your cart is empty</h2><Link to="/shop" className="btn btn-primary">Shop toys</Link></div></Layout>;
  return <Layout><section className="page-banner compact-banner"><span className="eyebrow">ALMOST THERE!</span><h1>Checkout</h1></section><section className="section-wrap checkout-layout"><form className="checkout-form" onSubmit={submit}><h2>Delivery details</h2>{error && <p className="form-error">{error}</p>}<p>Where should we send your happy package?</p><div className="form-grid"><label>Full name<input name="name" value={form.name} onChange={change} required placeholder="Your name"/></label><label>Email address<input name="email" type="email" value={form.email} onChange={change} required placeholder="you@example.com"/></label><label>Phone number<input name="phone" value={form.phone} onChange={change} required pattern="[0-9]{10}" title="Enter a 10-digit phone number" placeholder="10-digit mobile number"/></label><label>PIN code<input name="pincode" value={form.pincode} onChange={change} required pattern="[0-9]{6}" title="Enter a 6-digit PIN code" placeholder="6-digit PIN code"/></label><label className="full-field">Address<input name="address" value={form.address} onChange={change} required placeholder="House number, street and area"/></label><label className="full-field">City<input name="city" value={form.city} onChange={change} required placeholder="Your city"/></label></div><div className="payment-note"><ShieldCheck size={19}/><span><b>Demo checkout</b><small>No real payment will be collected in this project.</small></span></div><button className="btn btn-primary checkout-button" type="submit" disabled={busy}>{busy ? "Placing order..." : "Place order"} <ArrowRight size={18}/></button></form><aside className="summary-card"><h3>Your order</h3>{cart.map(i => {const p=products.find(x=>x.id===i.id);if(!p)return null;return <div className="checkout-item" key={i.id}><span>{p.emoji} {p.name} × {i.qty}</span><b>{money(p.price*i.qty)}</b></div>})}<div><span>Subtotal</span><b>{money(subtotal)}</b></div><div><span>Delivery</span><b>{delivery ? money(delivery) : "FREE"}</b></div><div className="summary-total"><span>Total</span><strong>{money(subtotal+delivery)}</strong></div></aside></section></Layout>;
}

function OrderSuccess() {
  const { setCart } = useStore();
  const order = JSON.parse(sessionStorage.getItem("toyland-order") || "null");
  useEffect(() => { setCart([]); }, []);
  return <Layout><section className="success-page"><div className="success-icon">🎉</div><span className="eyebrow">ORDER CONFIRMED</span><h1>Yay! Let the fun begin.</h1><p>Your demo order has been placed successfully.</p>{order && <div className="order-number">Order number <b>#{order.id}</b><br/><span>Total: {money(order.total)}</span></div>}<Link to="/shop" className="btn btn-primary">Keep exploring <ArrowRight size={18}/></Link></section></Layout>;
}

function AuthShell({ children, title, subtitle }) {
  return <div className="auth-page"><div className="auth-card"><Link to="/home" className="auth-brand"><span>🧸</span><b>Toy<span>Land</span></b></Link><h1>{title}</h1><p className="auth-subtitle">{subtitle}</p>{children}</div></div>;
}

function Signup() {
  const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [show,setShow]=useState(false); const [error,setError]=useState("");
  const {setUser}=useStore(); const navigate=useNavigate();
  const [busy,setBusy]=useState(false); const submit=async e=>{e.preventDefault(); setError(""); if(password.length<6){setError("Password must be at least 6 characters.");return;} setBusy(true); try { const data=await apiRequest("/api/users/register",{method:"POST",body:JSON.stringify({username,password})}); setUser({username:data.user.username,token:data.token}); navigate("/home"); } catch(err){setError(err.message);} finally{setBusy(false);} };
  return <AuthShell title="Create your account" subtitle="Join ToyLand and discover a world of play."><form className="auth-form" onSubmit={submit}><label>Username<input value={username} onChange={e=>setUsername(e.target.value)} required placeholder="Choose a username" autoComplete="username"/></label><label>Password<div className="password-wrap"><input type={show?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} required placeholder="At least 6 characters" autoComplete="new-password"/><button type="button" onClick={()=>setShow(!show)}>{show?"Hide":"Show"}</button></div></label>{error && <p className="form-error">{error}</p>}<div className="forgot-row"><Link to="/forgot-password">Forgot password?</Link></div><button className="btn btn-primary auth-submit" disabled={busy}>{busy?"Creating account...":"Create account"} <ArrowRight size={18}/></button></form><p className="auth-switch">Already have an account? <Link to="/login">Log in</Link></p><p className="auth-disclaimer">Your account is securely stored in the ToyLand database.</p></AuthShell>;
}

function Login() {
  const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState("");
  const {setUser}=useStore(); const navigate=useNavigate();
  const [busy,setBusy]=useState(false); const submit=async e=>{e.preventDefault(); setError(""); if(password.length<1){setError("Enter your password.");return;} setBusy(true); try { const data=await apiRequest("/api/users/login",{method:"POST",body:JSON.stringify({username,password})}); setUser({username:data.user.username,token:data.token}); navigate("/home"); } catch(err){setError(err.message);} finally{setBusy(false);} };
  return <AuthShell title="Welcome back!" subtitle="Log in and get back to the fun."><form className="auth-form" onSubmit={submit}><label>Username<input value={username} onChange={e=>setUsername(e.target.value)} required placeholder="Your username"/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required placeholder="Your password"/></label>{error&&<p className="form-error">{error}</p>}<div className="forgot-row"><Link to="/forgot-password">Forgot password?</Link></div><button className="btn btn-primary auth-submit" disabled={busy}>{busy?"Logging in...":"Log in"} <ArrowRight size={18}/></button></form><p className="auth-switch">New to ToyLand? <Link to="/">Create an account</Link></p><p className="auth-disclaimer">Sign in using your ToyLand account.</p></AuthShell>;
}

function ForgotPassword() {
  const [email,setEmail]=useState(""); const [sent,setSent]=useState(false);
  return <AuthShell title="Reset your password" subtitle="Enter your email and we'll show a demo confirmation.">{sent?<div className="reset-success"><span>✉️</span><b>Check your inbox</b><p>If this were connected to a backend, reset instructions would be sent to {email}.</p><Link to="/login">Back to login</Link></div>:<form className="auth-form" onSubmit={e=>{e.preventDefault();setSent(true);}}><label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="you@example.com"/></label><button className="btn btn-primary auth-submit">Continue <ArrowRight size={18}/></button><p className="auth-switch"><Link to="/login">Back to login</Link></p></form>}</AuthShell>;
}


const faqs = [
  { q: "How do I place an order?", a: "Browse the toy collection, add your favourites to the cart and continue to checkout. This project currently demonstrates the ordering flow only; it does not process real payments." },
  { q: "How much is delivery?", a: "Delivery is free on orders of ₹999 or more. Orders below ₹999 show a demo delivery charge of ₹79." },
  { q: "Can I return a toy?", a: "The storefront displays a 7-day return window as a sample policy. Contact the ToyLand team with your order details to discuss a return." },
  { q: "Are the toys suitable for every age?", a: "Each product page shows a recommended age range. Please check the age guidance and any product safety information before purchase." },
  { q: "How can I ask about a product?", a: "Use the Quick Enquiry Form or the Contact Us page and include the toy name and your question." },
  { q: "Is online payment available?", a: "No. This is a front-end demonstration and checkout does not collect payment or create a real shipment." }
];

function InfoBanner({ eyebrow, title, subtitle }) {
  return <section className="page-banner"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</section>;
}

function About() {
  return <Layout><InfoBanner eyebrow="OUR LITTLE STORY" title="A world built for play" subtitle="At ToyLand, we believe every great adventure begins with a little imagination."}/>
    <section className="section-wrap info-content">
      <div className="about-highlight"><span>🧸</span><div><h2>Little joys, big adventures.</h2><p>ToyLand is a cheerful demo toy store concept created to make discovering playtime favourites simple and fun. Our collection brings together cuddly companions, creative activities, learning toys and imaginative play sets.</p></div></div>
      <div className="info-grid"><article><span>🎨</span><h3>Encourage creativity</h3><p>Activities and toys that invite children to imagine, build and make.</p></article><article><span>🧩</span><h3>Learn through play</h3><p>Playful picks that can support curiosity, discovery and problem-solving.</p></article><article><span>💛</span><h3>Make happy moments</h3><p>Thoughtful gift ideas for birthdays, celebrations and everyday fun.</p></article></div>
      <div className="info-cta"><h2>Ready for a new adventure?</h2><Link className="btn btn-primary" to="/shop">Explore the toys <ArrowRight size={18}/></Link></div>
    </section>
  </Layout>;
}

function Contact() {
  const [sent,setSent]=useState(false);
  const [form,setForm]=useState({name:"",email:"",subject:"",message:""});
  const change=e=>setForm({...form,[e.target.name]:e.target.value});
  const submit=e=>{e.preventDefault();setSent(true);};
  return <Layout><InfoBanner eyebrow="WE'RE HERE TO HELP" title="Contact ToyLand" subtitle="Have a question, suggestion or need help with a toy? Send us a message."/>
    <section className="section-wrap contact-layout">
      <div className="contact-details"><h2>Say hello!</h2><p>Use the form and tell us how we can help. This demo stores no message on a server.</p><div>✉️ <span><b>Email</b><small>hello@toyland.example</small></span></div><div>🕘 <span><b>Support hours</b><small>Monday – Saturday, 9:00 AM – 6:00 PM</small></span></div><div>📍 <span><b>Location</b><small>Online toy store demo · India</small></span></div></div>
      {sent?<div className="form-success"><span>🎉</span><h2>Thanks for reaching out!</h2><p>Your message has been accepted in this demo. No email was sent.</p><button className="btn btn-primary" onClick={()=>{setSent(false);setForm({name:"",email:"",subject:"",message:""});}}>Send another message</button></div>:
      <form className="site-form" onSubmit={submit}><h2>Send us a message</h2><label>Your name<input name="name" value={form.name} onChange={change} required placeholder="Enter your name"/></label><label>Email address<input name="email" type="email" value={form.email} onChange={change} required placeholder="you@example.com"/></label><label>Subject<input name="subject" value={form.subject} onChange={change} required placeholder="How can we help?"/></label><label>Message<textarea name="message" value={form.message} onChange={change} required rows="5" placeholder="Write your message..."/></label><button className="btn btn-primary" type="submit">Send message <ArrowRight size={17}/></button></form>}
    </section>
  </Layout>;
}

function Enquiry() {
  const [sent,setSent]=useState(false);
  const [form,setForm]=useState({name:"",phone:"",email:"",toy:"",message:""});
  const change=e=>setForm({...form,[e.target.name]:e.target.value});
  return <Layout><InfoBanner eyebrow="NEED A HAND?" title="Quick Enquiry" subtitle="Ask about a toy, availability or a gift recommendation."/>
    <section className="section-wrap enquiry-wrap">{sent?<div className="form-success"><span>💌</span><h2>Enquiry submitted!</h2><p>Thanks, {form.name}. This is a front-end demo, so your enquiry has not been sent to a server.</p><button className="btn btn-primary" onClick={()=>{setSent(false);setForm({name:"",phone:"",email:"",toy:"",message:""});}}>Submit another enquiry</button></div>:
      <form className="site-form enquiry-form" onSubmit={e=>{e.preventDefault();setSent(true);}}><h2>Tell us what you need</h2><div className="form-grid"><label>Full name<input name="name" value={form.name} onChange={change} required placeholder="Your name"/></label><label>Phone number<input name="phone" value={form.phone} onChange={change} required pattern="[0-9]{10}" title="Enter a 10-digit phone number" placeholder="10-digit mobile number"/></label><label>Email address<input name="email" type="email" value={form.email} onChange={change} required placeholder="you@example.com"/></label><label>Toy name (optional)<input name="toy" value={form.toy} onChange={change} placeholder="Which toy are you asking about?"/></label><label className="full-field">Your enquiry<textarea name="message" value={form.message} onChange={change} required rows="5" placeholder="Type your question here..."/></label></div><button className="btn btn-primary" type="submit">Submit enquiry <ArrowRight size={17}/></button></form>}
    </section>
  </Layout>;
}

function FAQ() {
  const [open,setOpen]=useState(0);
  return <Layout><InfoBanner eyebrow="GOOD TO KNOW" title="Frequently Asked Questions" subtitle="Quick answers to common questions about shopping at ToyLand."/>
    <section className="section-wrap faq-wrap"><div className="faq-list">{faqs.map((item,i)=><article className={`faq-item ${open===i?"faq-open":""}`} key={item.q}><button onClick={()=>setOpen(open===i?-1:i)} aria-expanded={open===i}><span>{item.q}</span><b>{open===i?"−":"+"}</b></button>{open===i&&<p>{item.a}</p>}</article>)}</div><div className="faq-help"><b>Still have a question?</b><span>We'd be happy to help.</span><Link to="/contact" className="text-link">Contact us <ArrowRight size={16}/></Link></div></section>
  </Layout>;
}

function Terms() {
  return <Layout><InfoBanner eyebrow="THE IMPORTANT DETAILS" title="Terms & Conditions" subtitle="Please read these demo storefront terms before using ToyLand."/>
    <section className="section-wrap legal-content"><p className="legal-updated">Last updated: 19 November 2026</p>
      <h2>1. About this website</h2><p>ToyLand is an educational e-commerce demonstration. Product listings, prices, availability, delivery details and order confirmations are illustrative and may not represent real products or services.</p>
      <h2>2. Product information and pricing</h2><p>We aim to display clear product descriptions, age guidance and prices. In this demo, all prices are examples in Indian Rupees (INR). Product images are represented by illustrative emoji artwork.</p>
      <h2>3. Orders and payments</h2><p>The cart and checkout provide a sample shopping flow only. No real payment is collected, no real order is transmitted and no product is dispatched. An on-screen order confirmation is not a purchase contract.</p>
      <h2>4. Delivery and returns</h2><p>Delivery thresholds, charges and the 7-day return window shown on the site are sample content for demonstration. They are not a promise of actual delivery or a binding return policy.</p>
      <h2>5. Acceptable use</h2><p>Do not misuse the website, attempt to disrupt its operation or submit unlawful, harmful or misleading information through its forms.</p>
      <h2>6. Changes and contact</h2><p>These terms may be updated as the project develops. For questions about this demonstration, use the <Link to="/contact">Contact Us</Link> page.</p>
      <p className="legal-note">Project note: Replace this sample text with reviewed business terms before launching a real store.</p>
    </section>
  </Layout>;
}

function Privacy() {
  return <Layout><InfoBanner eyebrow="YOUR INFORMATION" title="Privacy Policy" subtitle="A simple explanation of data handling in this ToyLand demo."/>
    <section className="section-wrap legal-content"><p className="legal-updated">Last updated: 19 November 2026</p>
      <h2>1. Scope of this policy</h2><p>This policy describes the current front-end demonstration. It is not a substitute for a production privacy notice reviewed for your business and applicable laws.</p>
      <h2>2. Information you enter</h2><p>You may enter a username, checkout details, contact details or enquiry text while testing the site. Contact and enquiry forms only show a local confirmation; they do not send your message to a server.</p>
      <h2>3. Browser storage</h2><p>The demo uses your browser's local storage to remember the cart and signed-in demo username. A temporary order summary is kept in session storage to display the order-success screen. This information remains on the device/browser unless cleared.</p>
      <h2>4. Payments and third parties</h2><p>No payment information is requested or processed. The project does not currently connect to a payment gateway, customer database or email service. The page loads fonts from Google Fonts.</p>
      <h2>5. Children's privacy</h2><p>This is a toy-store themed project, not a service intended to collect personal information directly from children. A real store should provide appropriate safeguards and obtain any required parental consent.</p>
      <h2>6. Your choices and contact</h2><p>You can clear this site's browser storage through your browser settings. For questions about this demo, visit the <Link to="/contact">Contact Us</Link> page.</p>
      <p className="legal-note">Project note: Update this policy to match actual analytics, hosting, cookies, payment and customer-support integrations before production use.</p>
    </section>
  </Layout>;
}

function App() {
  return <StoreProvider><Routes>
    <Route path="/" element={<Signup/>}/>
    <Route path="/login" element={<Login/>}/>
    <Route path="/forgot-password" element={<ForgotPassword/>}/>
    <Route path="/home" element={<Home/>}/>
    <Route path="/shop" element={<Shop/>}/>
    <Route path="/product/:id" element={<ProductDetail/>}/>
    <Route path="/cart" element={<Cart/>}/>
    <Route path="/checkout" element={<Checkout/>}/>
    <Route path="/order-success" element={<OrderSuccess/>}/>
    <Route path="/about" element={<About/>}/>
    <Route path="/contact" element={<Contact/>}/>
    <Route path="/terms" element={<Terms/>}/>
    <Route path="/privacy" element={<Privacy/>}/>
    <Route path="/faq" element={<FAQ/>}/>
    <Route path="/enquiry" element={<Enquiry/>}/>
    <Route path="*" element={<Home/>}/>
  </Routes></StoreProvider>;
}

export default App;
