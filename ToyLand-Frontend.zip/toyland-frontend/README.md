# ToyLand E-Commerce Demo

A React + Vite toy-store storefront.

## Run locally
1. Install Node.js (LTS).
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev` and open the local URL printed by Vite.

## Pages
- Home, Shop, Product details, Cart and demo Checkout
- About, Contact Us, Terms & Conditions and Privacy Policy
- Frequently Asked Questions and Quick Enquiry Form
- Login, Signup and Forgot Password demo screens

## Notes
- Product catalogue includes 20 sample toys.
- Cart and demo username use browser local storage.
- Contact/enquiry forms show a front-end confirmation only; they do not send data.
- Checkout is a demo only. No payment is collected and no real order is placed.
- Replace sample policies, contact details, product data and demo flows before using this as a live store.
